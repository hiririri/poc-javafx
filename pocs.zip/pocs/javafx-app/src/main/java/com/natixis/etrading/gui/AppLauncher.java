package com.natixis.etrading.gui;

import com.natixis.etrading.gui.view.MainController;

public class AppLauncher {

    public static void main(String[] args) {
        MainController.main(args);
    }

}
