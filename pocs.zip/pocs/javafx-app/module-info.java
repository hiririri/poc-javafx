module com.natixis.etrading {
    requires javafx.controls;
    requires javafx.fxml;
    requires org.controlsfx.controls;
    requires org.slf4j;
    requires javafx.base;
    requires java.prefs;
    requires opencsv;

    opens com.natixis.etrading.gui.view to javafx.fxml;
    opens com.natixis.etrading.gui.model to javafx.base;

    exports com.natixis.etrading.gui;
}
