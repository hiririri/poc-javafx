package com.natixis.etrading.gui.view;

import com.jidesoft.grid.FilterableTableModel;
import com.natixis.etrading.gui.component.CustomTableCellRenderer;
import com.natixis.etrading.gui.component.NTable;
import com.natixis.etrading.gui.component.NTableHeader;
import com.natixis.etrading.gui.controller.JideTalePanelController;
import com.natixis.etrading.gui.model.CustomTableModel;
import com.natixis.etrading.gui.model.RowData;
import io.github.andrewauclair.moderndocking.Dockable;
import io.github.andrewauclair.moderndocking.app.Docking;
import io.github.andrewauclair.moderndocking.ui.DefaultDockingPanel;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.swing.*;
import javax.swing.filechooser.FileNameExtensionFilter;
import javax.swing.table.TableColumn;
import javax.swing.table.TableColumnModel;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class JideTablePanel extends DefaultDockingPanel implements Dockable {

    private static final Logger logger = LoggerFactory.getLogger(JideTablePanel.class);

    private static final String APP_TITLE = "Table Monitor";

    // Components
    private CustomTableModel tableModel;
    private FilterableTableModel filterModel;
    private NTable table;
    private Timer priceFlashTimer;
    private JButton startPauseButton;
    private JLabel statusLabel;
    private JLabel rowCountLabel;
    private JPopupMenu columnMenu;
    private final Map<TableColumn, Integer> columnOrder = new HashMap<>();

    private JideTalePanelController controller;

    public JideTablePanel(String persistentID) {
        super(persistentID, persistentID);

        this.setClosable(true);

        setLayout(new BorderLayout());

        // Toolbar
        add(createToolbar(), BorderLayout.NORTH);

        // Table with filter panel
        add(createTablePanel(), BorderLayout.CENTER);

        // Status bar
        add(createStatusBar(), BorderLayout.SOUTH);

        setupTableDoubleClickListener();

        Docking.registerDockable(this);
    }

    private JPanel createStatusBar() {
        JPanel statusBar = new JPanel(new BorderLayout());
        statusBar.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createMatteBorder(1, 0, 0, 0, Color.LIGHT_GRAY),
                BorderFactory.createEmptyBorder(4, 12, 4, 12)
        ));

        statusLabel = new JLabel("Ready");
        statusBar.add(statusLabel, BorderLayout.WEST);

        JLabel hintLabel = new JLabel("Use column filters to search data");
        hintLabel.setForeground(Color.GRAY);
        statusBar.add(hintLabel, BorderLayout.EAST);

        return statusBar;
    }

    private JPanel createToolbar() {
        JPanel toolbarContainer = new JPanel();
        toolbarContainer.setLayout(new BoxLayout(toolbarContainer, BoxLayout.Y_AXIS));
        toolbarContainer.setBorder(BorderFactory.createEmptyBorder(8, 12, 4, 12));

        // Title bar
        JPanel titleBar = new JPanel(new BorderLayout());
        JLabel appTitle = new JLabel(APP_TITLE);
        appTitle.setFont(appTitle.getFont().deriveFont(Font.BOLD, 18f));
        titleBar.add(appTitle, BorderLayout.WEST);

        rowCountLabel = new JLabel("Rows: 0");
        rowCountLabel.setFont(rowCountLabel.getFont().deriveFont(12f));
        titleBar.add(rowCountLabel, BorderLayout.EAST);

        toolbarContainer.add(titleBar);
        toolbarContainer.add(Box.createVerticalStrut(8));

        // Button toolbar
        JPanel buttonBar = new JPanel(new FlowLayout(FlowLayout.LEFT, 8, 0));

        // Control buttons
        startPauseButton = new JButton("Start");
        startPauseButton.setPreferredSize(new Dimension(100, 26));
        startPauseButton.addActionListener(e -> controller.onStartPause());
        buttonBar.add(startPauseButton);

        JButton columnsButton = new JButton("Columns");
        columnsButton.addActionListener(e -> columnMenu.show(columnsButton, 0, columnsButton.getHeight()));
        buttonBar.add(columnsButton);

        toolbarContainer.add(buttonBar);

        return toolbarContainer;
    }

    private JPanel createTablePanel() {
        JPanel panel = new JPanel(new BorderLayout(0, 4));
        panel.setBorder(BorderFactory.createEmptyBorder(4, 8, 4, 8));


        // Create table model and filter wrapper
        tableModel = new CustomTableModel();
        filterModel = new FilterableTableModel(tableModel);

        // Create table
        table = new NTable(filterModel);
        table.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);
        table.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);

        table.setRowHeight(24);
//        table.setShowGrid(true);
//        Color gridColor = new Color(196, 195, 177);
//        table.setGridColor(gridColor);
        table.getTableHeader().setReorderingAllowed(true);
        table.setDragEnabled(true);


        // Column chooser menu
        initColumnMenu();

        // Apply custom cell renderers for all columns
        for (int i = 0; i < tableModel.getColumnCount(); i++) {
            table.getColumnModel().getColumn(i).setCellRenderer(
                    new CustomTableCellRenderer(tableModel, filterModel, i)
            );
        }

        // JIDE auto filter header for per-column filtering
//        AutoFilterTableHeader filterHeader = new AutoFilterTableHeader(table);
//        filterHeader.setAutoFilterEnabled(true);
//        table.setTableHeader(filterHeader);

        NTableHeader header = new NTableHeader(table);
        header.setAutoFilterEnabled(true);
        header.setShowFilterName(true);
        header.setDoubleBuffered(true);
        header.setFrozenModelCol(0);
        table.setTableHeader(header);

        // Scroll pane with table
        JScrollPane scrollPane = new JScrollPane(table);
        scrollPane.getViewport().setScrollMode(JViewport.SIMPLE_SCROLL_MODE);
//        scrollPane.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
//        scrollPane.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_ALWAYS);

        scrollPane.setColumnHeaderView(header);
        header.installScrollSync();


        panel.add(scrollPane, BorderLayout.CENTER);

        // Repaint periodically to animate price flashing.
        priceFlashTimer = new Timer(180, e -> table.repaint());
        priceFlashTimer.start();

        // Listen for data/filter changes to update row count
        filterModel.addTableModelListener(e -> updateRowCount());

        return panel;
    }

    public void updateRowCount() {
        int total = tableModel.getRowCount();
        int filtered = table.getRowCount();

        if (filtered == total) {
            rowCountLabel.setText("Rows: %d".formatted(total));
        } else {
            rowCountLabel.setText("Rows: %d / %d".formatted(filtered, total));
        }
    }

    private void initColumnMenu() {
        columnMenu = new JPopupMenu();
        TableColumnModel columnModel = table.getColumnModel();
        columnOrder.clear();

        for (int i = 0; i < columnModel.getColumnCount(); i++) {
            TableColumn column = columnModel.getColumn(i);

            columnOrder.put(column, i);
            String name = tableModel.getColumnName(i);
            JCheckBoxMenuItem item = new JCheckBoxMenuItem(name, true);

            item.addActionListener(e -> toggleColumnVisibility(column, item.isSelected()));
            columnMenu.add(item);
        }
    }

    private void toggleColumnVisibility(TableColumn column, boolean visible) {
        TableColumnModel columnModel = table.getColumnModel();
        boolean isVisible = isColumnVisible(columnModel, column);

        if (visible && !isVisible) {
            columnModel.addColumn(column);
            reorderColumns(columnModel);
        } else if (!visible && isVisible) {
            columnModel.removeColumn(column);
        }

        table.getTableHeader().revalidate();
        table.getTableHeader().repaint();
    }

    private void reorderColumns(TableColumnModel columnModel) {
        List<TableColumn> columns = new ArrayList<>();
        for (int i = 0; i < columnModel.getColumnCount(); i++) {
            columns.add(columnModel.getColumn(i));
        }

        columns.sort((a, b) -> Integer.compare(
                columnOrder.getOrDefault(a, Integer.MAX_VALUE),
                columnOrder.getOrDefault(b, Integer.MAX_VALUE)
        ));

        for (int i = 0; i < columns.size(); i++) {
            TableColumn column = columns.get(i);
            int currentIndex = columnModel.getColumnIndex(column.getIdentifier());

            if (currentIndex != i) {
                columnModel.moveColumn(currentIndex, i);
            }
        }
    }

    private boolean isColumnVisible(TableColumnModel columnModel, TableColumn column) {
        for (int i = 0; i < columnModel.getColumnCount(); i++) {
            if (columnModel.getColumn(i) == column) {
                return true;
            }
        }

        return false;
    }

    public void setStatus(String message) {
        statusLabel.setText(message);
    }

    public CustomTableModel getTableModel() {
        return this.tableModel;
    }

    public void setStartPauseLabel(String labelText) {
        startPauseButton.setText(labelText);
    }

    public File promptOpenCsv() {
        JFileChooser chooser = new JFileChooser();
        chooser.setDialogTitle("Open CSV File");
        chooser.setFileFilter(new FileNameExtensionFilter("CSV Files", "csv"));

        if (chooser.showOpenDialog(this) == JFileChooser.APPROVE_OPTION) {
            return chooser.getSelectedFile();
        }
        return null;
    }

    public File promptSaveCsv() {
        JFileChooser chooser = new JFileChooser();
        chooser.setDialogTitle("Save CSV File");
        chooser.setFileFilter(new FileNameExtensionFilter("CSV Files", "csv"));
        chooser.setSelectedFile(new File("export.csv"));

        if (chooser.showSaveDialog(this) == JFileChooser.APPROVE_OPTION) {
            File file = chooser.getSelectedFile();
            if (!file.getName().endsWith(".csv")) {
                file = new File(file.getAbsolutePath() + ".csv");
            }
            return file;
        }
        return null;
    }

    public void setController(JideTalePanelController controller) {
        this.controller = controller;
    }

    private void setupTableDoubleClickListener() {
        table.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                if (e.getClickCount() == 2) {
                    onRowDoubleClick(e);
                }
            }
        });
    }

    public void onRowDoubleClick(MouseEvent e) {
        int selectedRow = table.getSelectedRow();
        if (selectedRow >= 0) {
            int modelRow = table.convertRowIndexToModel(selectedRow);
            CustomTableModel tableModel = getTableModel();

            if (modelRow < tableModel.getRowCount()) {
                RowData rowData = tableModel.getData().get(modelRow);
                showRowInfoPopup(rowData, selectedRow + 1, e);
                logger.info("Double-clicked on row {}: {}", selectedRow + 1, rowData);
            }
        }
    }

    private void showRowInfoPopup(RowData rowData, int displayRowNumber, MouseEvent mouseEvent) {
        JDialog dialog = new JDialog((Frame) SwingUtilities.getWindowAncestor(table), "Row Information", true);
        dialog.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
        dialog.setSize(400, 300);

        // Smart positioning near mouse click, avoiding screen edges
        Point mousePoint = mouseEvent.getLocationOnScreen();
        Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
        Dimension dialogSize = dialog.getSize();

        int x = mousePoint.x + 10;
        int y = mousePoint.y + 10;

        // Adjust if dialog would go off screen
        if (x + dialogSize.width > screenSize.width) {
            x = mousePoint.x - dialogSize.width - 10;
        }
        if (y + dialogSize.height > screenSize.height) {
            y = mousePoint.y - dialogSize.height - 10;
        }
        dialog.setLocation(Math.max(0, x), Math.max(0, y));

        JPanel mainPanel = new JPanel(new BorderLayout());
        mainPanel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        JLabel titleLabel = new JLabel("Row " + displayRowNumber + " Details", JLabel.CENTER);
        titleLabel.setFont(titleLabel.getFont().deriveFont(Font.BOLD, 16f));
        titleLabel.setBorder(BorderFactory.createEmptyBorder(0, 0, 10, 0));
        mainPanel.add(titleLabel, BorderLayout.NORTH);

        JPanel contentPanel = new JPanel(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 5, 5, 5);
        gbc.anchor = GridBagConstraints.WEST;

        addRowField(contentPanel, gbc, 0, "Id:", String.valueOf(rowData.getId()));
        addRowField(contentPanel, gbc, 1, "Symbol:", rowData.getSymbol());
        addRowField(contentPanel, gbc, 2, "Price:", String.format("%.4f", rowData.getPrice()));
        addRowField(contentPanel, gbc, 3, "Quantity:", String.valueOf(rowData.getQty()));
        addRowField(contentPanel, gbc, 4, "Status:", rowData.getStatus());
        addRowField(contentPanel, gbc, 5, "Timestamp:", rowData.getLastUpdate());

        JScrollPane scrollPane = new JScrollPane(contentPanel);
        scrollPane.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED);
        scrollPane.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
        mainPanel.add(scrollPane, BorderLayout.CENTER);

        JPanel buttonPanel = new JPanel(new FlowLayout());
        JButton closeButton = new JButton("Close");
        closeButton.addActionListener(e -> dialog.dispose());
        buttonPanel.add(closeButton);
        mainPanel.add(buttonPanel, BorderLayout.SOUTH);

        dialog.add(mainPanel);
        dialog.setVisible(true);
    }

    private void addRowField(JPanel panel, GridBagConstraints gbc, int row, String label, String value) {
        gbc.gridx = 0;
        gbc.gridy = row;
        gbc.weightx = 0.0;
        JLabel labelComponent = new JLabel(label);
        labelComponent.setFont(labelComponent.getFont().deriveFont(Font.BOLD));
        panel.add(labelComponent, gbc);

        gbc.gridx = 1;
        gbc.weightx = 1.0;
        gbc.fill = GridBagConstraints.HORIZONTAL;
        JTextField valueField = new JTextField(value);
        valueField.setEditable(false);
        valueField.setBackground(panel.getBackground());
        valueField.setBorder(BorderFactory.createEmptyBorder(2, 5, 2, 5));
        panel.add(valueField, gbc);
        gbc.fill = GridBagConstraints.NONE;
    }

}