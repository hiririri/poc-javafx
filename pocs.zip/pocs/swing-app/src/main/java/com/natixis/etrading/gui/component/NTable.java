package com.natixis.etrading.gui.component;

import com.jidesoft.grid.SortableTable;

import javax.swing.*;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.TableColumnModelEvent;
import javax.swing.table.TableModel;
import java.awt.*;
import java.awt.image.BufferedImage;

public class NTable extends SortableTable {

    private BufferedImage frozenCache;
    private int cacheW = -1;
    private int cacheH = -1;
    private int cacheViewY = -1;
    private boolean cacheDirty = true;

    private CellRendererPane rendererPane = new CellRendererPane();

    public NTable(TableModel tableModel) {
        super(tableModel);


        tableModel.addTableModelListener(e -> cacheDirty = true);
        addComponentListener(new java.awt.event.ComponentAdapter() {
            @Override
            public void componentResized(java.awt.event.ComponentEvent e) {
                cacheDirty = true;
            }
        });

        getColumnModel().addColumnModelListener(new javax.swing.event.TableColumnModelListener() {
            public void columnAdded(TableColumnModelEvent e) {
                cacheDirty = true;
            }

            public void columnRemoved(TableColumnModelEvent e) {
                cacheDirty = true;
            }

            public void columnMoved(TableColumnModelEvent e) {
                cacheDirty = true;
            }

            public void columnMarginChanged(ChangeEvent e) {
                cacheDirty = true;
            }

            public void columnSelectionChanged(ListSelectionEvent e) {
            }
        });

        getSelectionModel().addListSelectionListener(e -> {
            if (!e.getValueIsAdjusting()) cacheDirty = true;
        });
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        int frozenCol = 0;
        int scrollX = getViewPositionX();
        int w = getColumnModel().getColumn(frozenCol).getWidth();
        if (scrollX <= 0) return;
        Rectangle vr = getVisibleRect(); // 当前可视区域（相对 table 坐标）
        boolean adjusting = isAnyScrollAdjusting();
        if (!adjusting) {
            ensureFrozenCacheUpToDate(frozenCol, w, vr);
        } else {
            if (frozenCache == null || cacheDirty || cacheW != w || cacheH != vr.height || cacheViewY != vr.y) {
                ensureFrozenCacheUpToDate(frozenCol, w, vr);
            }
        }
        if (frozenCache != null) {
            Graphics2D g2 = (Graphics2D) g.create();
            try {
                g2.translate(scrollX, 0);
                g2.setClip(0, vr.y, w, vr.height);
                g2.drawImage(frozenCache, 0, vr.y, null);
                g2.setClip(null);
            } finally {
                g2.dispose();
            }
        }
    }

    private void ensureFrozenCacheUpToDate(int col, int w, Rectangle vr) {
        if (w <= 0 || vr.height <= 0) return;
        if (frozenCache == null || cacheW != w || cacheH != vr.height) {
            frozenCache = new BufferedImage(w, vr.height, BufferedImage.TYPE_INT_ARGB);
            cacheW = w;
            cacheH = vr.height;
            cacheDirty = true;
        }
        if (!cacheDirty && cacheViewY == vr.y) return;
        Graphics2D ig = frozenCache.createGraphics();
        try {
            ig.setComposite(AlphaComposite.Src);
            ig.setColor(getBackground());
            ig.fillRect(0, 0, w, vr.height);
            ig.translate(0, -vr.y);
            ig.setClip(0, vr.y, w, vr.height);
            paintFrozenColumnCellsInto(ig, col, w, vr);
        } finally {
            ig.dispose();
        }
        cacheViewY = vr.y;
        cacheDirty = false;
    }

    private void paintFrozenColumnCellsInto(Graphics2D g2, int col, int frozenWidth, Rectangle vr) {
        int first = rowAtPoint(new Point(0, vr.y));
        if (first < 0) first = 0;
        int last = rowAtPoint(new Point(0, vr.y + vr.height - 1));
        if (last < 0) last = getRowCount() - 1;
        for (int row = first; row <= last; row++) {
            Rectangle r = getCellRect(row, col, true);
            r.x = 0;
            r.width = frozenWidth;
            Component c = prepareRenderer(getCellRenderer(row, col), row, col);
            if (c instanceof JComponent jc) {
                jc.setBorder(BorderFactory.createMatteBorder(0, 0, 1, 1, getGridColor()));
            }
            rendererPane.paintComponent(g2, c, this, r.x, r.y, r.width, r.height, true);
        }
    }

    private int getViewPositionX() {
        Container p = SwingUtilities.getAncestorOfClass(JViewport.class, this);
        if (p instanceof JViewport vp) return vp.getViewPosition().x;
        return Math.max(0, -getX());
    }

    private boolean isAnyScrollAdjusting() {
        JScrollPane sp = (JScrollPane) SwingUtilities.getAncestorOfClass(JScrollPane.class, this);
        if (sp == null) return false;
        BoundedRangeModel hm = sp.getHorizontalScrollBar().getModel();
        BoundedRangeModel vm = sp.getVerticalScrollBar().getModel();
        return hm.getValueIsAdjusting() || vm.getValueIsAdjusting();
    }

}
