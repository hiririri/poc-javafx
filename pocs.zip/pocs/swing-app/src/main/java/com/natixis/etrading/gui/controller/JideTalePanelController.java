package com.natixis.etrading.gui.controller;

import com.natixis.etrading.gui.service.CsvRepository;
import com.natixis.etrading.gui.model.RowData;
import com.natixis.etrading.gui.service.PriceUpdateService;
import com.natixis.etrading.gui.model.CustomTableModel;
import com.natixis.etrading.gui.view.JideTablePanel;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.swing.*;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.File;
import java.util.List;
import java.util.concurrent.CompletableFuture;

public class JideTalePanelController {

    private static final Logger logger = LoggerFactory.getLogger(JideTalePanelController.class);

    private JideTablePanel view;
    private CsvRepository csvRepository;
    private PriceUpdateService priceUpdateService;
    private boolean updateRunning;

    public JideTalePanelController(JideTablePanel view, CsvRepository csvRepository, PriceUpdateService priceUpdateService) {
        this.view = view;
        this.csvRepository = csvRepository;
        this.priceUpdateService = priceUpdateService;
    }

    public void onViewReady() {
        setupUpdateEngine();
        loadDefaultCsv();
    }

    public void onOpenCsv() {
        File file = view.promptOpenCsv();
        loadCsvFromFile(file);
    }

    public void onSaveCsv() {
        File file = view.promptSaveCsv();
            saveCsvToFile(file);
    }

    public void onStartPause() {
        if (updateRunning) {
            pauseUpdates();
        } else {
            startUpdates();
        }
    }

    private void setupUpdateEngine() {
        priceUpdateService.setTableUpdateCallback(() -> view.getTableModel().fireTableDataChanged());
    }


    private void loadDefaultCsv() {
        logger.info("Loading default CSV...");
        view.setStatus("Loading default CSV...");

        CompletableFuture.runAsync(() -> {
            List<RowData> data = csvRepository.loadDefaultCsv();
            SwingUtilities.invokeLater(() -> applyLoadedData(data, "sample.csv"));
        }).exceptionally(ex -> {
            logger.error("Failed to load default CSV", ex);
            SwingUtilities.invokeLater(() -> view.setStatus("Failed to load CSV: " + ex.getMessage()));
            return null;
        });
    }

    private void loadCsvFromFile(File file) {
        logger.info("Loading CSV from file: {}", file.getName());
        view.setStatus("Loading " + file.getName() + "...");

        boolean wasRunning = updateRunning;
        if (wasRunning) {
            pauseUpdates();
        }

        String fileName = file.getName();

        CompletableFuture.runAsync(() -> {
            List<RowData> data = csvRepository.loadCsvFromFile(file);
            SwingUtilities.invokeLater(() -> {
                applyLoadedData(data, fileName);
                if (wasRunning) {
                    startUpdates();
                }
            });
        }).exceptionally(ex -> {
            logger.error("Failed to load CSV from file: {}", fileName, ex);
            SwingUtilities.invokeLater(() -> {
                if (wasRunning) {
                    startUpdates();
                }
                view.setStatus("Failed to load " + fileName + ": " + ex.getMessage());
            });
            return null;
        });
    }

    private void applyLoadedData(List<RowData> data, String sourceName) {
        CustomTableModel tableModel = view.getTableModel();
        tableModel.setData(data);
        priceUpdateService.setData(tableModel.getData());
        view.updateRowCount();
        view.setStatus("Loaded %d rows from %s".formatted(data.size(), sourceName));
        logger.info("Loaded {} rows from {}", data.size(), sourceName);
    }

    private void saveCsvToFile(File file) {
        logger.info("Saving CSV to file: {}", file.getName());
        view.setStatus("Saving to " + file.getName() + "...");

        CustomTableModel tableModel = view.getTableModel();
        boolean success = csvRepository.saveCsvToFile(tableModel.getData(), file);

        if (success) {
            view.setStatus("Saved %d rows to %s".formatted(tableModel.getRowCount(), file.getName()));
        } else {
            view.setStatus("Failed to save to " + file.getName());
        }
    }

    private void startUpdates() {
        priceUpdateService.start();
        updateRunning = true;
        view.setStartPauseLabel("Pause");
        view.setStatus("Real-time updates started");
        logger.info("Updates started");
    }

    private void pauseUpdates() {
        priceUpdateService.pause();
        updateRunning = false;
        view.setStartPauseLabel("Start");
        view.setStatus("Real-time updates paused");
        logger.info("Updates paused");
    }

    private void shutdown() {
        logger.info("Application closing...");
        priceUpdateService.shutdown();
    }

}
