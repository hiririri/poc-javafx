package com.natixis.etrading.gui.component;

import com.jidesoft.grid.AutoFilterTableHeader;
import com.jidesoft.grid.SortableTable;

import javax.swing.*;
import java.awt.*;
import java.awt.event.MouseEvent;

public class NTableHeader extends AutoFilterTableHeader {
    private final SortableTable table;
    private int frozenModelCol = 0;

    public NTableHeader(SortableTable table) {
        super(table);
        this.table = table;
    }

    public void setFrozenModelCol(int modelCol) {
        this.frozenModelCol = modelCol;
        repaint();
        revalidate();
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        int anchorX = getVisibleRect().x;
        if (anchorX <= 0) {
            return;
        }

        int frozenViewCol = table.convertColumnIndexToView(frozenModelCol);
        if (frozenViewCol < 0) {
            return;
        }

        Rectangle src = super.getHeaderRect(frozenViewCol);
        int w = src.width;
        int h = getHeight();
        if (w <= 0 || h <= 0) {
            return;
        }

        Graphics2D g2 = (Graphics2D) g.create();
        try {
            g2.setClip(anchorX, 0, w, h);

            g2.setComposite(AlphaComposite.Src);
            g2.setBackground(getBackground());
            g2.fillRect(anchorX, 0, w, h);

            g2.translate(anchorX - src.x, 0);

            super.paintComponent(g2);
        } finally {
            g2.dispose();
        }
    }

    @Override
    public int columnAtPoint(Point p) {
        int anchorX = getVisibleRect().x;
        if (anchorX <= 0) {
            return super.columnAtPoint(p);
        }

        int frozenViewCol = table.convertColumnIndexToView(frozenModelCol);
        if (frozenViewCol < 0) {
            return super.columnAtPoint(p);
        }

        Rectangle real = super.getHeaderRect(frozenViewCol);
        int w = real.width;

        if (p.x >= anchorX && p.x < anchorX + w) {
            return frozenViewCol;
        }

        return super.columnAtPoint(p);
    }

    @Override
    public void doLayout() {
        super.doLayout();

        if (!isEditing()) {
            return;
        }

        int editingCol = getEditingColumn();
        int frozenViewCol = table.convertColumnIndexToView(frozenModelCol);
        if (editingCol != frozenViewCol) {
            return;
        }

        Component editor = getEditorComponent();
        if (editor == null) {
            return;
        }

        int anchorX = getVisibleRect().x;
        Rectangle real = super.getHeaderRect(frozenViewCol);

        editor.setBounds(anchorX, real.y, real.width, real.height);
    }

    @Override
    protected void processMouseEvent(MouseEvent e) {
        super.processMouseEvent(mapFrozenEvent(e));
    }

    @Override
    protected void processMouseMotionEvent(MouseEvent e) {
        super.processMouseMotionEvent(mapFrozenEvent(e));
    }

    @Override
    public String getToolTipText(MouseEvent e) {
        return super.getToolTipText(mapFrozenEvent(e));
    }

    private MouseEvent mapFrozenEvent(MouseEvent e) {
        int anchorX = getVisibleRect().x;
        if (anchorX <= 0) {
            return e;
        }

        int frozenViewCol = table.convertColumnIndexToView(frozenModelCol);
        if (frozenViewCol < 0) {
            return e;
        }

        Rectangle src = super.getHeaderRect(frozenViewCol);
        int w = src.width;
        int x = e.getX();
        if (x < anchorX || x >= anchorX + w) {
            return e;
        }

        int mappedX = src.x + (x - anchorX);
        return new MouseEvent(
                e.getComponent(),
                e.getID(),
                e.getWhen(),
                e.getModifiersEx(),
                mappedX,
                e.getY(),
                e.getClickCount(),
                e.isPopupTrigger(),
                e.getButton()
        );
    }

    public void installScrollSync() {
        JViewport hvp = (JViewport) SwingUtilities.getAncestorOfClass(JViewport.class, this);
        if (hvp == null) return;
        hvp.setScrollMode(JViewport.SIMPLE_SCROLL_MODE);
        final int frozenModelCol = 0;
        final int[] lastAnchor = {-1};

        hvp.addChangeListener(ev -> SwingUtilities.invokeLater(() -> {
            int anchorX = getVisibleRect().x;
            if (anchorX < 0) anchorX = 0;
            int frozenViewCol = table.convertColumnIndexToView(frozenModelCol);
            if (frozenViewCol < 0) return;
            int w = getColumnModel().getColumn(frozenViewCol).getWidth();
            int h = getHeight();
            if (lastAnchor[0] < 0) lastAnchor[0] = anchorX;
            int x = Math.min(lastAnchor[0], anchorX);
            int ww = Math.abs(lastAnchor[0] - anchorX) + w + 3;
            lastAnchor[0] = anchorX;
            repaint(x, 0, ww, h);
            revalidate();
        }));
    }
}