package com.natixis.etrading.gui.view;

import com.natixis.etrading.gui.controller.JideTalePanelController;
import com.natixis.etrading.gui.service.CsvRepository;
import com.natixis.etrading.gui.service.PriceUpdateService;
import io.github.andrewauclair.moderndocking.DockableTabPreference;
import io.github.andrewauclair.moderndocking.DockingRegion;
import io.github.andrewauclair.moderndocking.app.Docking;
import io.github.andrewauclair.moderndocking.app.RootDockingPanel;
import io.github.andrewauclair.moderndocking.ext.ui.DockingUI;
import io.github.andrewauclair.moderndocking.settings.Settings;
import io.github.andrewauclair.moderndocking.ui.HeaderController;

import javax.swing.*;
import java.awt.*;
import java.util.ArrayList;
import java.util.List;

public class MainFrame extends JFrame {


    private List<JideTablePanel> tablePanelList;

    private List<JideTalePanelController> controllerList;

    private List<HeaderController> headerControllerList;

    public MainFrame() {
        setTitle("E-Trading Application");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(1000, 700);
        setLocationRelativeTo(null);

        Docking.initialize(this);
        DockingUI.initialize();

        Settings.setDefaultTabPreference(DockableTabPreference.TOP_ALWAYS);

        RootDockingPanel rootDockingPanel = new RootDockingPanel(this);

        add(rootDockingPanel, BorderLayout.CENTER);

        tablePanelList = new ArrayList<>();
        controllerList = new ArrayList<>();
        headerControllerList = new ArrayList<>();

        initComponents();
    }

    private void initComponents() {
        SwingUtilities.invokeLater(() -> {
            // Tab 1: Your existing JideTablePanel
            tablePanelList.add(new JideTablePanel("Table " + (tablePanelList.size() + 1)));
            var tablePanel = tablePanelList.getFirst();

            controllerList.add(new JideTalePanelController(tablePanel, new CsvRepository(), new PriceUpdateService()));
            var controller = controllerList.getFirst();
            controller.onViewReady();

            tablePanel.setController(controller);
            tablePanel.addDockingListener(dockingEvent -> {

            });

            Docking.dock(tablePanel, this);

            // Optional: Add a menu bar
            setJMenuBar(createMenuBar());
        });
    }

    private JMenuBar createMenuBar() {
        JMenuBar menuBar = new JMenuBar();

        JMenu fileMenu = new JMenu("File");

        JMenuItem openFileMenuItem = new JMenuItem("Open");
        JMenuItem saveFileMenuItem = new JMenuItem("Save");
        JMenuItem exitMenuItem = new JMenuItem("Exit");

        openFileMenuItem.addActionListener(e -> controllerList.getFirst().onOpenCsv());
        saveFileMenuItem.addActionListener(e -> controllerList.getFirst().onSaveCsv());
        exitMenuItem.addActionListener(e -> System.exit(0));

        fileMenu.add(openFileMenuItem);
        fileMenu.add(saveFileMenuItem);
        fileMenu.addSeparator();
        fileMenu.add(exitMenuItem);

        JMenu viewMenu = new JMenu("View");

        JMenuItem addTableMenuItem = new JMenuItem("Add Table View");
        addTableMenuItem.addActionListener(e -> {
            tablePanelList.add(new JideTablePanel("Table " + (tablePanelList.size() + 1)));
            var secondLastComponent = tablePanelList.get(tablePanelList.size() - 2);
            var lastComponent = tablePanelList.getLast();

            controllerList.add(new JideTalePanelController(lastComponent, new CsvRepository(), new PriceUpdateService()));
            var controller = controllerList.getLast();
            controller.onViewReady();

            lastComponent.setController(controller);

            Docking.dock(lastComponent, secondLastComponent, DockingRegion.CENTER, 0.8);
        });
        viewMenu.add(addTableMenuItem);

        menuBar.add(fileMenu);
        menuBar.add(viewMenu);

        return menuBar;
    }

}