package com.natixis.etrading.gui;


import com.formdev.flatlaf.FlatIntelliJLaf;
import com.natixis.etrading.gui.view.MainFrame;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.swing.*;

public class SwingApp {

    private static final Logger logger = LoggerFactory.getLogger(SwingApp.class);

    public static void main(String[] args) {
        logger.info("Starting CSV Table Monitor (Swing)...");


        SwingUtilities.invokeLater(() -> {
            try {
                UIManager.setLookAndFeel(new FlatIntelliJLaf());
            } catch (Exception e) {
                logger.error("Error setting up FlatLaf look and feel", e);
            }

            new MainFrame().setVisible(true);
        });
    }
}

