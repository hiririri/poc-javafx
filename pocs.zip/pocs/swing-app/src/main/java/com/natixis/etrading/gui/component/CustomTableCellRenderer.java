package com.natixis.etrading.gui.component;

import com.jidesoft.grid.FilterableTableModel;
import com.natixis.etrading.gui.model.CustomTableModel;
import com.natixis.etrading.gui.model.RowData;

import javax.swing.*;
import javax.swing.table.DefaultTableCellRenderer;
import java.awt.*;

public class CustomTableCellRenderer extends DefaultTableCellRenderer {

    private static final Color ALERT_BG = new Color(0xFF, 0xCC, 0xCC);    // Light red
    private static final Color NORMAL_BG = new Color(0xE6, 0xFF, 0xE6);   // Light green
    private static final Color PENDING_BG = new Color(0xFF, 0xF2, 0xCC);  // Light orange
    private static final Color ACTIVE_BG = new Color(0xCC, 0xE6, 0xFF);   // Light blue
    private static final Color CLOSED_BG = new Color(0xE6, 0xE6, 0xE6);   // Light gray
    private static final Color PRICE_FLASH = new Color(0, 255, 3); // Light amber
    private static final long PRICE_FLASH_WINDOW_MS = 800;

    private final CustomTableModel tableModel;
    private final FilterableTableModel filterableTableModel;

    private final boolean isPriceColumn;

    public CustomTableCellRenderer(CustomTableModel tableModel, FilterableTableModel filterableTableModel, int columnIndex) {
        this.tableModel = tableModel;
        this.filterableTableModel = filterableTableModel;
        this.isPriceColumn = columnIndex == 2;

        // Set alignment based on column type
        switch (columnIndex) {
            case 0 -> setHorizontalAlignment(SwingConstants.CENTER);  // ID
            case 1 -> setHorizontalAlignment(SwingConstants.LEFT);    // Symbol
            case 2 -> setHorizontalAlignment(SwingConstants.RIGHT);   // Price
            case 3 -> setHorizontalAlignment(SwingConstants.RIGHT);   // Qty
            case 4 -> setHorizontalAlignment(SwingConstants.CENTER);  // Status
            case 5 -> setHorizontalAlignment(SwingConstants.LEFT);    // LastUpdate
        }
    }

    @Override
    public Component getTableCellRendererComponent(JTable table,
                                                   Object value,
                                                   boolean isSelected,
                                                   boolean hasFocus,
                                                   int row,
                                                   int column) {

        Component c = super.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, column);

        RowData rowData = resolveRowData(table, row);

        if (rowData == null) {
            return c;
        }

        applyBackground(table, c, rowData, isSelected);
        applyPriceFormatting(c, value);

        return c;
    }

    private RowData resolveRowData(JTable table, int viewRow) {
        int modelRow = table.convertRowIndexToModel(viewRow);
        return tableModel.getRowAt(filterableTableModel.getActualRowAt(modelRow));
    }

    private void applyBackground(JTable table, Component c, RowData rowData, boolean isSelected) {
        if (isSelected) {
            Color statusBg = getStatusBackgroundColor(rowData.getStatus());
            if (statusBg != null) {
                c.setBackground(blend(table.getSelectionBackground(), statusBg, 0.7f));
            }
            return;
        }

        if (isPriceColumn && shouldFlashPrice(rowData)) {
            c.setBackground(PRICE_FLASH);
            return;
        }

        Color bgColor = getStatusBackgroundColor(rowData.getStatus());
        c.setBackground(bgColor != null ? bgColor : table.getBackground());
    }

    private void applyPriceFormatting(Component c, Object value) {
        if (!isPriceColumn || !(value instanceof Double price)) {
            return;
        }
        if (c instanceof JLabel label) {
            label.setText(formatPriceWithEmphasis(price));
        } else {
            setText(String.format("%.5f", price));
        }
    }

    private boolean shouldFlashPrice(RowData rowData) {
        return System.currentTimeMillis() - rowData.getLastPriceChangeAt() < PRICE_FLASH_WINDOW_MS;
    }

    private Color getStatusBackgroundColor(String status) {
        if (status == null) return null;

        return switch (status.toUpperCase()) {
            case "ALERT" -> ALERT_BG;
            case "NORMAL" -> NORMAL_BG;
            case "PENDING" -> PENDING_BG;
            case "ACTIVE" -> ACTIVE_BG;
            case "CLOSED" -> CLOSED_BG;
            default -> null;
        };
    }

    /**
     * Blend two colors together.
     */
    private Color blend(Color c1, Color c2, float ratio) {
        float iRatio = 1.0f - ratio;
        int r = (int) (c1.getRed() * ratio + c2.getRed() * iRatio);
        int g = (int) (c1.getGreen() * ratio + c2.getGreen() * iRatio);
        int b = (int) (c1.getBlue() * ratio + c2.getBlue() * iRatio);
        return new Color(r, g, b);
    }

    private String formatPriceWithEmphasis(double price) {
        String formatted = String.format("%.5f", price);

        int dotIndex = formatted.indexOf(',');
        if (dotIndex < 0) {
            return formatted;
        }

        String intPart = formatted.substring(0, dotIndex + 1);
        String frac = formatted.substring(dotIndex + 1);

        if (frac.length() < 4) {
            return formatted;
        }

        String firstTwo = frac.substring(0, 2);
        String emph = frac.substring(2, 4);
        String rest = frac.substring(4);

        return "<html>%s%s<b><span style='font-size:110%%'>%s</span></b>%s</html>"
                .formatted(intPart, firstTwo, emph, rest);
    }

}
